<?php

//Load the classes
require 'classes/Utility.php';

$total = 125;

echo Utility::formatCurrency($total);