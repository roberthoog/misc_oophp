<?php

class Form{
    protected $elements = [];
    protected $name;
    public $valid = false;
}
