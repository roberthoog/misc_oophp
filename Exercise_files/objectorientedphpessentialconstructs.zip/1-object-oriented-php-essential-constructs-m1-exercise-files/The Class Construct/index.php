<?php

$fields = ['username', 'password', 'hairColor'];

//Use of a crop rotation extension that defines a fields variable
$fields = ['soy_beans', 'corn', 'potatoes'];

print_r($fields);