<?php
/**
 * Created by PhpStorm.
 * User: daryl
 * Date: 5/11/15
 * Time: 2:54 PM
 */

class Test {
    public function __destruct(){
        echo 'Done in Test';
    }
}