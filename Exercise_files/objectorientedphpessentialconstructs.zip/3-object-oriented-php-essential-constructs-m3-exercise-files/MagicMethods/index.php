<?php
//Load the class
require 'classes/Form.php';

$form = new Form();
