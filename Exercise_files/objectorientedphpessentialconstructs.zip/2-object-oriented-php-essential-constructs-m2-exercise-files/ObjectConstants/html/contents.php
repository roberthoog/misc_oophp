<html>
<head>
    Head Stuff
</head>
<body>
    Body Stuff
</body>
</html>