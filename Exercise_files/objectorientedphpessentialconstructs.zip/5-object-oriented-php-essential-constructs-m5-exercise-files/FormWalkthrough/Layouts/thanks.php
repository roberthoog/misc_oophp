<html>
<body>
<div id="content">
    <?php echo 'Thanks for your registration'?>
</div>
</body>
</html>